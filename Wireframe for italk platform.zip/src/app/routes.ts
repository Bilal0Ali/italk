import { createBrowserRouter } from "react-router";
import { Layout } from "./components/Layout";
import { Dashboard } from "./pages/Dashboard";
import { TrainingChat } from "./pages/TrainingChat";
import { MyClone } from "./pages/MyClone";
import { CloneNetwork } from "./pages/CloneNetwork";
import { CloneConversations } from "./pages/CloneConversations";
import { Analytics } from "./pages/Analytics";
import { Journal } from "./pages/Journal";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: Dashboard },
      { path: "training", Component: TrainingChat },
      { path: "my-clone", Component: MyClone },
      { path: "network", Component: CloneNetwork },
      { path: "conversations", Component: CloneConversations },
      { path: "journal", Component: Journal },
      { path: "analytics", Component: Analytics },
    ],
  },
]);
