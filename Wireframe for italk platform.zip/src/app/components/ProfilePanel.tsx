import { useState } from "react";
import {
  User,
  Mail,
  Users,
  UserPlus,
  Share2,
  Brain,
  Database,
  Trash2,
  Settings,
  GitFork,
  Heart,
  Lock,
  Bell,
  Sun,
  Moon,
  Globe,
  FileText,
  Shield,
  HelpCircle,
  LogOut,
  AlertTriangle,
  X,
  ChevronRight,
  Eye,
  Sliders,
} from "lucide-react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { ScrollArea } from "./ui/scroll-area";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription, SheetTrigger } from "./ui/sheet";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "./ui/alert-dialog";
import { cn } from "./ui/utils";

interface ProfilePanelProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  trigger?: React.ReactNode;
}

export function ProfilePanel({ open, onOpenChange, trigger }: ProfilePanelProps) {
  const [showDeleteCloneDialog, setShowDeleteCloneDialog] = useState(false);
  const [showLogoutDialog, setShowLogoutDialog] = useState(false);
  const [showDeleteAccountDialog, setShowDeleteAccountDialog] = useState(false);

  // Mock data
  const friends = [
    { id: "1", name: "Alex Chen", initials: "AC", color: "from-green-500 to-teal-500", status: "online" },
    { id: "2", name: "Sarah Johnson", initials: "SJ", color: "from-pink-500 to-rose-500", status: "online" },
    { id: "3", name: "Michael Brown", initials: "MB", color: "from-orange-500 to-yellow-500", status: "offline" },
    { id: "4", name: "Emma Wilson", initials: "EW", color: "from-purple-500 to-indigo-500", status: "offline" },
  ];

  const cloneMemoryStats = {
    conversations: 1247,
    traits: 42,
    preferences: 28,
    dataSize: "2.3 MB",
  };

  const content = (
    <div className="flex flex-col h-full">
      {/* Profile Header */}
      <div className="p-4 lg:p-6 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 lg:w-20 lg:h-20 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white text-xl lg:text-2xl font-bold flex-shrink-0">
            JD
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="text-lg lg:text-xl font-bold text-gray-900 dark:text-gray-100">John Doe</h2>
            <p className="text-sm text-gray-600 dark:text-gray-400 truncate">john@example.com</p>
            <Badge className="mt-2 bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 hover:bg-green-100 dark:hover:bg-green-900">
              <div className="w-2 h-2 rounded-full bg-green-500 mr-2 animate-pulse" />
              Active Clone
            </Badge>
          </div>
        </div>
      </div>

      {/* Scrollable Content */}
      <ScrollArea className="flex-1">
        <div className="p-4 lg:p-6 space-y-6">
          {/* Section 1: Social & Connections */}
          <div>
            <h3 className="flex items-center gap-2 text-base lg:text-lg font-semibold text-gray-900 dark:text-gray-100 mb-3">
              <Users className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              Social & Connections
            </h3>
            <Card>
              <CardContent className="p-4 space-y-4">
                {/* Friends List */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      Friends ({friends.length})
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    {friends.map((friend) => (
                      <button
                        key={friend.id}
                        className="flex items-center gap-2 p-2 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors text-left"
                      >
                        <div className="relative">
                          <div className={`w-10 h-10 rounded-full bg-gradient-to-br ${friend.color} flex items-center justify-center text-white text-xs font-bold`}>
                            {friend.initials}
                          </div>
                          {friend.status === "online" && (
                            <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white dark:border-gray-800 rounded-full" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-medium text-gray-900 dark:text-gray-100 truncate">
                            {friend.name}
                          </p>
                          <p className="text-xs text-gray-500 dark:text-gray-400">{friend.status}</p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-2 pt-3 border-t border-gray-200 dark:border-gray-700">
                  <Button variant="outline" size="sm" className="flex-1 h-9">
                    <UserPlus className="w-4 h-4 mr-2" />
                    Add Friends
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1 h-9">
                    <Share2 className="w-4 h-4 mr-2" />
                    Invite
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Section 2: Clone Management */}
          <div>
            <h3 className="flex items-center gap-2 text-base lg:text-lg font-semibold text-gray-900 dark:text-gray-100 mb-3">
              <Brain className="w-5 h-5 text-purple-600 dark:text-purple-400" />
              Clone Management
            </h3>
            <Card>
              <CardContent className="p-4 space-y-3">
                {/* Clone Memory Stats */}
                <div className="grid grid-cols-2 gap-2 pb-3 border-b border-gray-200 dark:border-gray-700">
                  <div className="text-center p-2 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <div className="text-lg font-bold text-blue-600 dark:text-blue-400">
                      {cloneMemoryStats.conversations}
                    </div>
                    <div className="text-xs text-gray-600 dark:text-gray-400">Messages</div>
                  </div>
                  <div className="text-center p-2 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                    <div className="text-lg font-bold text-purple-600 dark:text-purple-400">
                      {cloneMemoryStats.traits}
                    </div>
                    <div className="text-xs text-gray-600 dark:text-gray-400">Traits</div>
                  </div>
                  <div className="text-center p-2 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <div className="text-lg font-bold text-green-600 dark:text-green-400">
                      {cloneMemoryStats.preferences}
                    </div>
                    <div className="text-xs text-gray-600 dark:text-gray-400">Preferences</div>
                  </div>
                  <div className="text-center p-2 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                    <div className="text-lg font-bold text-orange-600 dark:text-orange-400">
                      {cloneMemoryStats.dataSize}
                    </div>
                    <div className="text-xs text-gray-600 dark:text-gray-400">Data Size</div>
                  </div>
                </div>

                {/* Clone Actions */}
                <button className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                  <div className="flex items-center gap-3">
                    <Eye className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                    <span className="text-sm text-gray-900 dark:text-gray-100">View Clone Memory</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400" />
                </button>

                <button className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                  <div className="flex items-center gap-3">
                    <Sliders className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                    <span className="text-sm text-gray-900 dark:text-gray-100">Personality Settings</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400" />
                </button>

                <Button
                  variant="outline"
                  size="sm"
                  className="w-full h-9 border-red-300 dark:border-red-800 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20"
                  onClick={() => setShowDeleteCloneDialog(true)}
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Reset Clone Memory
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Section 3: Activity & History */}
          <div>
            <h3 className="flex items-center gap-2 text-base lg:text-lg font-semibold text-gray-900 dark:text-gray-100 mb-3">
              <GitFork className="w-5 h-5 text-green-600 dark:text-green-400" />
              Activity & History
            </h3>
            <Card>
              <CardContent className="p-4 space-y-2">
                <button className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                  <div className="flex items-center gap-3">
                    <GitFork className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                    <span className="text-sm text-gray-900 dark:text-gray-100">Past Clone Talks</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-xs">24</Badge>
                    <ChevronRight className="w-4 h-4 text-gray-400" />
                  </div>
                </button>

                <button className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                  <div className="flex items-center gap-3">
                    <Heart className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                    <span className="text-sm text-gray-900 dark:text-gray-100">Compatibility Checks</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-xs">12</Badge>
                    <ChevronRight className="w-4 h-4 text-gray-400" />
                  </div>
                </button>
              </CardContent>
            </Card>
          </div>

          {/* Section 4: Privacy & Controls */}
          <div>
            <h3 className="flex items-center gap-2 text-base lg:text-lg font-semibold text-gray-900 dark:text-gray-100 mb-3">
              <Lock className="w-5 h-5 text-orange-600 dark:text-orange-400" />
              Privacy & Controls
            </h3>
            <Card>
              <CardContent className="p-4 space-y-2">
                <button className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                  <div className="flex items-center gap-3">
                    <Users className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                    <span className="text-sm text-gray-900 dark:text-gray-100">Clone Interaction Settings</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400" />
                </button>

                <button className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                  <div className="flex items-center gap-3">
                    <Heart className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                    <span className="text-sm text-gray-900 dark:text-gray-100">Compatibility Check Access</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400" />
                </button>

                <button className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                  <div className="flex items-center gap-3">
                    <Bell className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                    <span className="text-sm text-gray-900 dark:text-gray-100">Notification Preferences</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400" />
                </button>
              </CardContent>
            </Card>
          </div>

          {/* Section 5: Account & App Settings */}
          <div>
            <h3 className="flex items-center gap-2 text-base lg:text-lg font-semibold text-gray-900 dark:text-gray-100 mb-3">
              <Settings className="w-5 h-5 text-gray-600 dark:text-gray-400" />
              Account & App Settings
            </h3>
            <Card>
              <CardContent className="p-4 space-y-2">
                <button className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                  <div className="flex items-center gap-3">
                    <Sun className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                    <span className="text-sm text-gray-900 dark:text-gray-100">Theme Preference</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-500 dark:text-gray-400">System</span>
                    <ChevronRight className="w-4 h-4 text-gray-400" />
                  </div>
                </button>

                <button className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                  <div className="flex items-center gap-3">
                    <Globe className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                    <span className="text-sm text-gray-900 dark:text-gray-100">Language</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-500 dark:text-gray-400">English</span>
                    <ChevronRight className="w-4 h-4 text-gray-400" />
                  </div>
                </button>
              </CardContent>
            </Card>
          </div>

          {/* Section 6: Legal & Support */}
          <div>
            <h3 className="flex items-center gap-2 text-base lg:text-lg font-semibold text-gray-900 dark:text-gray-100 mb-3">
              <Shield className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              Legal & Support
            </h3>
            <Card>
              <CardContent className="p-4 space-y-2">
                <button className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                  <div className="flex items-center gap-3">
                    <FileText className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                    <span className="text-sm text-gray-900 dark:text-gray-100">Terms and Conditions</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400" />
                </button>

                <button className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                  <div className="flex items-center gap-3">
                    <Shield className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                    <span className="text-sm text-gray-900 dark:text-gray-100">Privacy Policy</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400" />
                </button>

                <button className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                  <div className="flex items-center gap-3">
                    <HelpCircle className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                    <span className="text-sm text-gray-900 dark:text-gray-100">Help & Support</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400" />
                </button>
              </CardContent>
            </Card>
          </div>

          {/* Section 7: Account Actions */}
          <div className="pb-4">
            <h3 className="flex items-center gap-2 text-base lg:text-lg font-semibold text-gray-900 dark:text-gray-100 mb-3">
              <User className="w-5 h-5 text-red-600 dark:text-red-400" />
              Account Actions
            </h3>
            <Card>
              <CardContent className="p-4 space-y-2">
                <Button
                  variant="outline"
                  className="w-full h-10 justify-start"
                  onClick={() => setShowLogoutDialog(true)}
                >
                  <LogOut className="w-4 h-4 mr-3" />
                  Log Out
                </Button>

                <Button
                  variant="outline"
                  className="w-full h-10 justify-start border-red-300 dark:border-red-800 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20"
                  onClick={() => setShowDeleteAccountDialog(true)}
                >
                  <AlertTriangle className="w-4 h-4 mr-3" />
                  Delete Account
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </ScrollArea>

      {/* Confirmation Dialogs */}
      {/* Delete Clone Memory Dialog */}
      <AlertDialog open={showDeleteCloneDialog} onOpenChange={setShowDeleteCloneDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-600" />
              Reset Clone Memory?
            </AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete all your clone's learned data including:
              <ul className="list-disc list-inside mt-2 space-y-1">
                <li>{cloneMemoryStats.conversations} training messages</li>
                <li>{cloneMemoryStats.traits} personality traits</li>
                <li>{cloneMemoryStats.preferences} learned preferences</li>
              </ul>
              <p className="mt-3 font-semibold text-red-600 dark:text-red-400">
                This action cannot be undone. You'll need to retrain your clone from scratch.
              </p>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-red-600 hover:bg-red-700">
              Yes, Reset Clone Memory
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Logout Dialog */}
      <AlertDialog open={showLogoutDialog} onOpenChange={setShowLogoutDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Log Out?</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to log out? You'll need to sign in again to access your account.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction>Log Out</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete Account Dialog */}
      <AlertDialog open={showDeleteAccountDialog} onOpenChange={setShowDeleteAccountDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-600" />
              Delete Account Permanently?
            </AlertDialogTitle>
            <AlertDialogDescription>
              <p className="font-semibold text-red-600 dark:text-red-400 mb-3">
                ⚠️ This action is permanent and cannot be undone!
              </p>
              <p className="mb-2">Deleting your account will:</p>
              <ul className="list-disc list-inside space-y-1 mb-3">
                <li>Permanently delete your AI clone and all its learned data</li>
                <li>Remove all your journal entries and photos</li>
                <li>Delete your connection with friends</li>
                <li>Erase all conversation history</li>
                <li>Cancel any active subscriptions</li>
              </ul>
              <p className="text-sm">
                If you're sure, type <strong>"DELETE"</strong> below to confirm.
              </p>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-red-600 hover:bg-red-700">
              Permanently Delete Account
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );

  return (
    <>
      {/* Desktop: Side Drawer (Right) */}
      <Sheet open={open} onOpenChange={onOpenChange}>
        {trigger && <SheetTrigger asChild>{trigger}</SheetTrigger>}
        <SheetContent 
          side="right" 
          className="w-full sm:w-[400px] lg:w-[480px] p-0 hidden lg:flex lg:flex-col"
        >
          <SheetHeader className="p-4 lg:p-6 border-b border-gray-200 dark:border-gray-700">
            <SheetTitle className="flex items-center gap-2">
              <User className="w-5 h-5" />
              Profile
            </SheetTitle>
            <SheetDescription className="sr-only">
              View and manage your profile settings, clone data, and account preferences
            </SheetDescription>
          </SheetHeader>
          {content}
        </SheetContent>
      </Sheet>

      {/* Mobile: Bottom Sheet */}
      <Sheet open={open} onOpenChange={onOpenChange}>
        {trigger && <SheetTrigger asChild>{trigger}</SheetTrigger>}
        <SheetContent 
          side="bottom" 
          className="w-full h-[90vh] rounded-t-2xl p-0 flex flex-col lg:hidden"
        >
          <SheetHeader className="p-4 border-b border-gray-200 dark:border-gray-700 flex-shrink-0">
            <div className="w-12 h-1.5 bg-gray-300 dark:bg-gray-600 rounded-full mx-auto mb-4" />
            <SheetTitle className="flex items-center gap-2">
              <User className="w-5 h-5" />
              Profile
            </SheetTitle>
            <SheetDescription className="sr-only">
              View and manage your profile settings, clone data, and account preferences
            </SheetDescription>
          </SheetHeader>
          {content}
        </SheetContent>
      </Sheet>
    </>
  );
}