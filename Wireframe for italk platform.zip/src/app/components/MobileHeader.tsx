import { Menu } from "lucide-react";
import { ThemeToggle } from "./ThemeToggle";
import { Button } from "./ui/button";
import { Sheet, SheetContent, SheetTrigger, SheetDescription } from "./ui/sheet";
import { Link, useLocation } from "react-router";
import { Brain, MessageSquare, Users, GitFork, BarChart3, Sparkles, BookOpen } from "lucide-react";
import { cn } from "./ui/utils";

interface MobileHeaderProps {
  onProfileClick: () => void;
}

export function MobileHeader({ onProfileClick }: MobileHeaderProps) {
  const location = useLocation();

  const navItems = [
    { path: "/", label: "Dashboard", icon: Sparkles },
    { path: "/training", label: "Training Chat", icon: MessageSquare },
    { path: "/my-clone", label: "My Clone", icon: Brain },
    { path: "/network", label: "Clone Network", icon: Users },
    { path: "/conversations", label: "Clone Talks", icon: GitFork },
    { path: "/journal", label: "Journal", icon: BookOpen },
    { path: "/analytics", label: "Analytics", icon: BarChart3 },
  ];

  return (
    <header className="lg:hidden sticky top-0 z-40 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
      <div className="flex items-center justify-between px-4 h-14">
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="lg:hidden">
              <Menu className="w-5 h-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-64 p-0">
            <SheetDescription className="sr-only">
              Navigation menu for italk app
            </SheetDescription>
            <div className="flex flex-col h-full">
              <div className="p-6 border-b border-gray-200 dark:border-gray-700">
                <h1 className="text-2xl font-bold text-blue-600 dark:text-blue-400">italk</h1>
                <p className="text-sm text-gray-500 dark:text-gray-400">AI Personality Clones</p>
              </div>
              
              <nav className="flex-1 p-4 space-y-1">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = location.pathname === item.path;
                  
                  return (
                    <Link
                      key={item.path}
                      to={item.path}
                      className={cn(
                        "flex items-center gap-3 px-4 py-3 rounded-lg transition-colors",
                        isActive
                          ? "bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400"
                          : "text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                      )}
                    >
                      <Icon className="w-5 h-5" />
                      <span>{item.label}</span>
                    </Link>
                  );
                })}
              </nav>

              <div className="p-4 border-t border-gray-200 dark:border-gray-700">
                <button
                  onClick={onProfileClick}
                  className="flex items-center gap-3 px-4 py-3 w-full rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                >
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white">
                    JD
                  </div>
                  <div className="flex-1 text-left">
                    <p className="text-sm font-medium text-gray-900 dark:text-gray-100">John Doe</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">john@example.com</p>
                  </div>
                </button>
              </div>
            </div>
          </SheetContent>
        </Sheet>

        <h1 className="text-lg font-bold text-blue-600 dark:text-blue-400">italk</h1>
        
        <ThemeToggle />
      </div>
    </header>
  );
}