import { Link, useLocation } from "react-router";
import { Brain, MessageSquare, Users, GitFork, BarChart3, Sparkles, BookOpen } from "lucide-react";
import { cn } from "./ui/utils";

export function MobileNav() {
  const location = useLocation();

  const navItems = [
    { path: "/", label: "Home", icon: Sparkles },
    { path: "/training", label: "Train", icon: MessageSquare },
    { path: "/my-clone", label: "Clone", icon: Brain },
    { path: "/network", label: "Network", icon: Users },
    { path: "/conversations", label: "Talks", icon: GitFork },
    { path: "/journal", label: "Journal", icon: BookOpen },
    { path: "/analytics", label: "Stats", icon: BarChart3 },
  ];

  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 z-50 safe-area-inset-bottom">
      <div className="grid grid-cols-7 h-16">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          
          return (
            <Link
              key={item.path}
              to={item.path}
              className={cn(
                "flex flex-col items-center justify-center gap-1 transition-colors",
                isActive
                  ? "text-blue-600 dark:text-blue-400"
                  : "text-gray-600 dark:text-gray-400"
              )}
            >
              <Icon className="w-5 h-5" />
              <span className="text-xs">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}