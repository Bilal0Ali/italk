import { Outlet, Link, useLocation } from "react-router";
import { Brain, MessageSquare, Users, GitFork, BarChart3, Sparkles, BookOpen } from "lucide-react";
import { cn } from "./ui/utils";
import { ThemeToggle } from "./ThemeToggle";
import { MobileHeader } from "./MobileHeader";
import { MobileNav } from "./MobileNav";
import { ProfilePanel } from "./ProfilePanel";
import { useState } from "react";

export function Layout() {
  const location = useLocation();
  const [profileOpen, setProfileOpen] = useState(false);

  const navItems = [
    { path: "/", label: "Dashboard", icon: Sparkles },
    { path: "/training", label: "Training Chat", icon: MessageSquare },
    { path: "/my-clone", label: "My Clone", icon: Brain },
    { path: "/network", label: "Clone Network", icon: Users },
    { path: "/conversations", label: "Clone Talks", icon: GitFork },
    { path: "/journal", label: "Journal", icon: BookOpen },
    { path: "/analytics", label: "Analytics", icon: BarChart3 },
  ];

  return (
    <div className="flex h-screen bg-gray-50 dark:bg-gray-900">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex w-64 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 flex-col">
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <h1 className="text-2xl font-bold text-blue-600 dark:text-blue-400">italk</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400">AI Personality Clones</p>
        </div>
        
        <nav className="flex-1 p-4 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            
            return (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-lg transition-colors",
                  isActive
                    ? "bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400"
                    : "text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                )}
              >
                <Icon className="w-5 h-5" />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-gray-200 dark:border-gray-700">
          <button
            onClick={() => setProfileOpen(true)}
            className="flex items-center gap-3 px-4 py-3 w-full rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          >
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white">
              JD
            </div>
            <div className="flex-1 text-left">
              <p className="text-sm font-medium text-gray-900 dark:text-gray-100">John Doe</p>
              <p className="text-xs text-gray-500 dark:text-gray-400">john@example.com</p>
            </div>
          </button>
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-40">
        <MobileHeader onProfileClick={() => setProfileOpen(true)} />
      </div>

      {/* Main Content */}
      <main className="flex-1 overflow-auto relative pt-14 lg:pt-0 pb-16 lg:pb-0">
        {/* Desktop Theme Toggle - Top Right Corner */}
        <div className="hidden lg:block absolute top-6 right-8 z-10">
          <ThemeToggle />
        </div>
        <Outlet />
      </main>

      {/* Mobile Bottom Navigation */}
      <MobileNav />

      {/* Profile Panel */}
      <ProfilePanel open={profileOpen} onOpenChange={setProfileOpen} />
    </div>
  );
}