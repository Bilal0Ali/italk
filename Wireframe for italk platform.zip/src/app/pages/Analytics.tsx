import { TrendingUp, Brain, MessageSquare, Users, Calendar } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Legend } from "recharts";

export function Analytics() {
  const learningProgressData = [
    { week: "Week 1", accuracy: 45, messages: 120 },
    { week: "Week 2", accuracy: 58, messages: 210 },
    { week: "Week 3", accuracy: 67, messages: 280 },
    { week: "Week 4", accuracy: 78, messages: 340 },
  ];

  const personalityRadarData = [
    { trait: "Analytical", value: 85 },
    { trait: "Empathy", value: 78 },
    { trait: "Decisiveness", value: 72 },
    { trait: "Creativity", value: 68 },
    { trait: "Enthusiasm", value: 75 },
    { trait: "Adaptability", value: 80 },
  ];

  const conversationTopicsData = [
    { topic: "Technology", count: 145 },
    { topic: "Coffee & Food", count: 98 },
    { topic: "Creative Projects", count: 87 },
    { topic: "Philosophy", count: 76 },
    { topic: "Travel", count: 54 },
    { topic: "Sports", count: 42 },
  ];

  const weeklyActivityData = [
    { day: "Mon", messages: 42, conversations: 8 },
    { day: "Tue", messages: 38, conversations: 6 },
    { day: "Wed", messages: 55, conversations: 11 },
    { day: "Thu", messages: 48, conversations: 9 },
    { day: "Fri", messages: 61, conversations: 12 },
    { day: "Sat", messages: 35, conversations: 7 },
    { day: "Sun", messages: 28, conversations: 5 },
  ];

  const keyMetrics = [
    { label: "Clone Accuracy", value: "78%", change: "+12%", trend: "up" },
    { label: "Training Sessions", value: "47", change: "+8", trend: "up" },
    { label: "Active Connections", value: "24", change: "+3", trend: "up" },
    { label: "Avg Response Time", value: "1.2s", change: "-0.3s", trend: "up" },
  ];

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">Analytics</h1>
        <p className="text-gray-500 dark:text-gray-400 mt-1">Track your AI clone's development and performance</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {keyMetrics.map((metric) => (
          <Card key={metric.label}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{metric.label}</CardTitle>
              <TrendingUp className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{metric.value}</div>
              <p className="text-xs text-green-600 mt-2">
                {metric.change} from last month
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="progress" className="space-y-6">
        <TabsList>
          <TabsTrigger value="progress">Learning Progress</TabsTrigger>
          <TabsTrigger value="personality">Personality Profile</TabsTrigger>
          <TabsTrigger value="activity">Activity Patterns</TabsTrigger>
          <TabsTrigger value="topics">Topic Analysis</TabsTrigger>
        </TabsList>

        <TabsContent value="progress">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="w-5 h-5 text-blue-600" />
                Clone Learning Progress Over Time
              </CardTitle>
              <CardDescription>Accuracy improvement and training message volume</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={learningProgressData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="week" stroke="#6b7280" />
                  <YAxis yAxisId="left" stroke="#6b7280" />
                  <YAxis yAxisId="right" orientation="right" stroke="#6b7280" />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb', borderRadius: '8px' }}
                  />
                  <Legend />
                  <Line
                    yAxisId="left"
                    type="monotone"
                    dataKey="accuracy"
                    stroke="#3b82f6"
                    strokeWidth={3}
                    name="Accuracy %"
                    dot={{ fill: '#3b82f6', r: 5 }}
                  />
                  <Line
                    yAxisId="right"
                    type="monotone"
                    dataKey="messages"
                    stroke="#8b5cf6"
                    strokeWidth={3}
                    name="Training Messages"
                    dot={{ fill: '#8b5cf6', r: 5 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="personality">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="w-5 h-5 text-purple-600" />
                  Personality Trait Profile
                </CardTitle>
                <CardDescription>Multi-dimensional personality analysis</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <RadarChart data={personalityRadarData}>
                    <PolarGrid stroke="#e5e7eb" />
                    <PolarAngleAxis dataKey="trait" stroke="#6b7280" />
                    <PolarRadiusAxis stroke="#6b7280" />
                    <Radar
                      name="Personality Strength"
                      dataKey="value"
                      stroke="#8b5cf6"
                      fill="#8b5cf6"
                      fillOpacity={0.6}
                    />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb', borderRadius: '8px' }}
                    />
                  </RadarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Trait Development Summary</CardTitle>
                <CardDescription>Detailed breakdown of learned characteristics</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {personalityRadarData.map((trait) => (
                  <div key={trait.trait} className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="font-medium text-gray-700">{trait.trait}</span>
                      <span className="font-bold text-gray-900">{trait.value}%</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-purple-500 to-blue-500"
                        style={{ width: `${trait.value}%` }}
                      />
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="activity">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-green-600" />
                Weekly Activity Pattern
              </CardTitle>
              <CardDescription>Training messages and clone conversations by day</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={weeklyActivityData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="day" stroke="#6b7280" />
                  <YAxis stroke="#6b7280" />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb', borderRadius: '8px' }}
                  />
                  <Legend />
                  <Bar dataKey="messages" fill="#3b82f6" name="Training Messages" radius={[8, 8, 0, 0]} />
                  <Bar dataKey="conversations" fill="#10b981" name="Clone Conversations" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="topics">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-orange-600" />
                Conversation Topics Distribution
              </CardTitle>
              <CardDescription>Most discussed topics in training and clone conversations</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={conversationTopicsData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis type="number" stroke="#6b7280" />
                  <YAxis dataKey="topic" type="category" stroke="#6b7280" width={120} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb', borderRadius: '8px' }}
                  />
                  <Bar dataKey="count" fill="#f59e0b" name="Message Count" radius={[0, 8, 8, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}