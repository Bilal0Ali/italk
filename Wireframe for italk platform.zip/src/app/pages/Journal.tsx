import { useState } from "react";
import { 
  Calendar as CalendarIcon, 
  Camera, 
  Image as ImageIcon, 
  Mic, 
  MicOff,
  Save, 
  Flame,
  ChevronLeft,
  ChevronRight,
  X,
  Check,
  Clock,
  Search,
  Filter,
  BookOpen
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Calendar } from "../components/ui/calendar";
import { Input } from "../components/ui/input";
import { cn } from "../components/ui/utils";

export function Journal() {
  const [journalText, setJournalText] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [showImageOptions, setShowImageOptions] = useState(false);
  const [currentStreak, setCurrentStreak] = useState(7);
  const [longestStreak, setLongestStreak] = useState(14);
  const [selectedMonth, setSelectedMonth] = useState(new Date());
  const [viewMode, setViewMode] = useState<"write" | "history">("write");
  const [searchQuery, setSearchQuery] = useState("");

  // Mock data for journaling days (dates with entries)
  const journalingDays = [
    new Date(2026, 1, 9),
    new Date(2026, 1, 10),
    new Date(2026, 1, 11),
    new Date(2026, 1, 12),
    new Date(2026, 1, 13),
    new Date(2026, 1, 14),
    new Date(2026, 1, 15), // Today - 7 day streak
  ];

  // Mock journal entries
  const journalEntries = [
    {
      id: "1",
      date: "2026-02-15",
      title: "Amazing day at the park",
      preview: "Today was wonderful! Spent time outdoors and felt really refreshed...",
      mood: "happy",
      images: 2,
      wordCount: 247,
    },
    {
      id: "2",
      date: "2026-02-14",
      title: "Work reflections",
      preview: "Had an interesting conversation with my team today about project priorities...",
      mood: "thoughtful",
      images: 0,
      wordCount: 182,
    },
    {
      id: "3",
      date: "2026-02-13",
      title: "Morning meditation",
      preview: "Started my day with 20 minutes of meditation. Feeling centered and calm...",
      mood: "peaceful",
      images: 1,
      wordCount: 156,
    },
  ];

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      const newImages = Array.from(files).map(file => URL.createObjectURL(file));
      setUploadedImages([...uploadedImages, ...newImages]);
    }
    setShowImageOptions(false);
  };

  const handleCameraCapture = () => {
    // In a real app, this would trigger camera API
    console.log("Opening camera...");
    setShowImageOptions(false);
  };

  const handleVoiceRecording = () => {
    setIsRecording(!isRecording);
    if (!isRecording) {
      // In a real app, this would start voice recording
      console.log("Starting voice recording...");
      // Simulate voice-to-text
      setTimeout(() => {
        setJournalText(journalText + " [Voice recording would be transcribed here]");
        setIsRecording(false);
      }, 3000);
    }
  };

  const removeImage = (index: number) => {
    setUploadedImages(uploadedImages.filter((_, i) => i !== index));
  };

  const handleSaveEntry = () => {
    console.log("Saving journal entry:", { text: journalText, images: uploadedImages });
    // In a real app, this would save to backend
    alert("Journal entry saved!");
  };

  const wordCount = journalText.trim().split(/\s+/).filter(word => word.length > 0).length;
  const charCount = journalText.length;

  return (
    <div className="p-4 lg:p-8 max-w-7xl mx-auto">
      {/* Header with Streak */}
      <div className="mb-4 lg:mb-6">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            <h1 className="text-2xl lg:text-3xl font-bold text-gray-900 dark:text-gray-100 flex items-center gap-2">
              <BookOpen className="w-6 h-6 lg:w-8 lg:h-8 text-blue-600 dark:text-blue-400" />
              My Journal
            </h1>
            <p className="text-sm lg:text-base text-gray-500 dark:text-gray-400 mt-1">
              Capture your thoughts, memories, and reflections
            </p>
          </div>
          
          {/* Streak Display */}
          <div className="flex-shrink-0">
            <Card className="bg-gradient-to-br from-orange-50 to-red-50 dark:from-orange-900/20 dark:to-red-900/20 border-orange-200 dark:border-orange-800">
              <CardContent className="p-3 lg:p-4">
                <div className="flex items-center gap-2 lg:gap-3">
                  <Flame className="w-6 h-6 lg:w-8 lg:h-8 text-orange-500" />
                  <div>
                    <div className="text-2xl lg:text-3xl font-bold text-orange-600 dark:text-orange-400">
                      {currentStreak}
                    </div>
                    <div className="text-xs text-orange-700 dark:text-orange-300">
                      Day Streak
                    </div>
                  </div>
                </div>
                <div className="text-xs text-gray-600 dark:text-gray-400 mt-2 pt-2 border-t border-orange-200 dark:border-orange-800">
                  Best: {longestStreak} days
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* View Mode Toggle */}
      <div className="flex gap-2 mb-4 lg:mb-6">
        <Button
          variant={viewMode === "write" ? "default" : "outline"}
          onClick={() => setViewMode("write")}
          className="flex-1 lg:flex-initial"
        >
          Write New Entry
        </Button>
        <Button
          variant={viewMode === "history" ? "default" : "outline"}
          onClick={() => setViewMode("history")}
          className="flex-1 lg:flex-initial"
        >
          View History
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 lg:gap-6">
        {/* Main Journaling Area */}
        <div className="lg:col-span-2 space-y-4 lg:space-y-6">
          {viewMode === "write" ? (
            <>
              {/* Writing Interface */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-base lg:text-lg">Today's Entry</CardTitle>
                      <CardDescription className="text-xs lg:text-sm">
                        {new Date().toLocaleDateString('en-US', { 
                          weekday: 'long', 
                          year: 'numeric', 
                          month: 'long', 
                          day: 'numeric' 
                        })}
                      </CardDescription>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      <Clock className="w-3 h-3 mr-1" />
                      Auto-saving
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Toolbar */}
                  <div className="flex flex-wrap gap-2 pb-4 border-b border-gray-200 dark:border-gray-700">
                    {/* Image Upload Options */}
                    <div className="relative">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setShowImageOptions(!showImageOptions)}
                        className="h-9 lg:h-9"
                      >
                        <ImageIcon className="w-4 h-4 mr-2" />
                        Add Photos
                      </Button>
                      
                      {showImageOptions && (
                        <div className="absolute top-full mt-2 left-0 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg z-10 min-w-[200px]">
                          <label className="flex items-center gap-3 px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer transition-colors">
                            <ImageIcon className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                            <span className="text-sm text-gray-900 dark:text-gray-100">From Gallery</span>
                            <input
                              type="file"
                              accept="image/*"
                              multiple
                              onChange={handleImageUpload}
                              className="hidden"
                            />
                          </label>
                          <button
                            onClick={handleCameraCapture}
                            className="flex items-center gap-3 px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-700 w-full text-left transition-colors"
                          >
                            <Camera className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                            <span className="text-sm text-gray-900 dark:text-gray-100">Take Photo</span>
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Voice Recording */}
                    <Button
                      variant={isRecording ? "default" : "outline"}
                      size="sm"
                      onClick={handleVoiceRecording}
                      className={cn(
                        "h-9 lg:h-9",
                        isRecording && "bg-red-600 hover:bg-red-700 animate-pulse"
                      )}
                    >
                      {isRecording ? (
                        <>
                          <MicOff className="w-4 h-4 mr-2" />
                          <span className="hidden sm:inline">Stop Recording</span>
                          <span className="sm:hidden">Stop</span>
                        </>
                      ) : (
                        <>
                          <Mic className="w-4 h-4 mr-2" />
                          <span className="hidden sm:inline">Voice to Text</span>
                          <span className="sm:hidden">Voice</span>
                        </>
                      )}
                    </Button>

                    {/* Save Button */}
                    <Button
                      size="sm"
                      onClick={handleSaveEntry}
                      className="ml-auto h-9 lg:h-9 bg-blue-600 hover:bg-blue-700"
                      disabled={journalText.trim().length === 0}
                    >
                      <Save className="w-4 h-4 mr-2" />
                      Save Entry
                    </Button>
                  </div>

                  {/* Image Preview */}
                  {uploadedImages.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {uploadedImages.map((image, index) => (
                        <div key={index} className="relative group">
                          <img
                            src={image}
                            alt={`Upload ${index + 1}`}
                            className="w-20 h-20 lg:w-24 lg:h-24 object-cover rounded-lg border-2 border-gray-200 dark:border-gray-700"
                          />
                          <button
                            onClick={() => removeImage(index)}
                            className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Text Editor */}
                  <div>
                    <textarea
                      value={journalText}
                      onChange={(e) => setJournalText(e.target.value)}
                      placeholder="What's on your mind today? Start writing your thoughts, feelings, or experiences..."
                      className="w-full min-h-[300px] lg:min-h-[400px] p-4 text-sm lg:text-base text-gray-900 dark:text-gray-100 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 resize-none"
                    />
                  </div>

                  {/* Word Count */}
                  <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400 pt-2 border-t border-gray-200 dark:border-gray-700">
                    <span>{wordCount} words</span>
                    <span>{charCount} characters</span>
                  </div>
                </CardContent>
              </Card>

              {/* Writing Tips */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-base lg:text-lg">Writing Prompts</CardTitle>
                  <CardDescription className="text-xs lg:text-sm">
                    Need inspiration? Try one of these prompts
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {[
                      "What made you smile today?",
                      "What are you grateful for right now?",
                      "Describe a recent challenge and how you handled it",
                      "What's something new you learned this week?",
                    ].map((prompt, index) => (
                      <button
                        key={index}
                        onClick={() => setJournalText(journalText + prompt + "\n\n")}
                        className="w-full text-left px-3 lg:px-4 py-2 lg:py-3 text-xs lg:text-sm text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-blue-50 dark:hover:bg-blue-900/20 hover:border-blue-300 dark:hover:border-blue-700 transition-colors"
                      >
                        {prompt}
                      </button>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </>
          ) : (
            <>
              {/* History View */}
              <Card>
                <CardHeader>
                  <div className="flex items-center gap-2 flex-wrap">
                    <div className="flex-1 min-w-[200px]">
                      <Input
                        placeholder="Search entries..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="h-9"
                      />
                    </div>
                    <Button variant="outline" size="sm" className="h-9">
                      <Filter className="w-4 h-4 mr-2" />
                      Filter
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 lg:space-y-4">
                    {journalEntries.map((entry) => (
                      <button
                        key={entry.id}
                        className="w-full text-left p-3 lg:p-4 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg hover:border-blue-300 dark:hover:border-blue-700 hover:shadow-md transition-all"
                      >
                        <div className="flex items-start justify-between gap-3 mb-2">
                          <h3 className="font-semibold text-sm lg:text-base text-gray-900 dark:text-gray-100">
                            {entry.title}
                          </h3>
                          <span className="text-xs text-gray-500 dark:text-gray-400 flex-shrink-0">
                            {new Date(entry.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                          </span>
                        </div>
                        <p className="text-xs lg:text-sm text-gray-600 dark:text-gray-400 mb-3 line-clamp-2">
                          {entry.preview}
                        </p>
                        <div className="flex items-center gap-3 text-xs text-gray-500 dark:text-gray-400">
                          <span>{entry.wordCount} words</span>
                          {entry.images > 0 && (
                            <>
                              <span>•</span>
                              <span className="flex items-center gap-1">
                                <ImageIcon className="w-3 h-3" />
                                {entry.images}
                              </span>
                            </>
                          )}
                        </div>
                      </button>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </div>

        {/* Sidebar - Calendar & Stats */}
        <div className="space-y-4 lg:space-y-6">
          {/* Calendar Streak Tracker */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base lg:text-lg">Journaling Calendar</CardTitle>
              <CardDescription className="text-xs lg:text-sm">
                Track your daily writing streak
              </CardDescription>
            </CardHeader>
            <CardContent>
              {/* Custom Calendar Month Navigation */}
              <div className="mb-4">
                <div className="flex items-center justify-between mb-3">
                  <button
                    onClick={() => setSelectedMonth(new Date(selectedMonth.getFullYear(), selectedMonth.getMonth() - 1))}
                    className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                  >
                    <ChevronLeft className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                  </button>
                  <span className="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {selectedMonth.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
                  </span>
                  <button
                    onClick={() => setSelectedMonth(new Date(selectedMonth.getFullYear(), selectedMonth.getMonth() + 1))}
                    className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                  >
                    <ChevronRight className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                  </button>
                </div>

                {/* Calendar Grid */}
                <div className="grid grid-cols-7 gap-1">
                  {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((day) => (
                    <div key={day} className="text-center text-xs font-medium text-gray-500 dark:text-gray-400 py-2">
                      {day}
                    </div>
                  ))}
                  
                  {/* Generate calendar days */}
                  {Array.from({ length: 35 }, (_, i) => {
                    const firstDay = new Date(selectedMonth.getFullYear(), selectedMonth.getMonth(), 1).getDay();
                    const daysInMonth = new Date(selectedMonth.getFullYear(), selectedMonth.getMonth() + 1, 0).getDate();
                    const dayNumber = i - firstDay + 1;
                    const isCurrentMonth = dayNumber > 0 && dayNumber <= daysInMonth;
                    const date = new Date(selectedMonth.getFullYear(), selectedMonth.getMonth(), dayNumber);
                    const hasEntry = journalingDays.some(d => 
                      d.getDate() === date.getDate() && 
                      d.getMonth() === date.getMonth() && 
                      d.getFullYear() === date.getFullYear()
                    );
                    const isToday = new Date().toDateString() === date.toDateString();

                    return (
                      <div
                        key={i}
                        className={cn(
                          "aspect-square flex items-center justify-center text-xs rounded-lg transition-all",
                          isCurrentMonth ? "text-gray-900 dark:text-gray-100" : "text-gray-300 dark:text-gray-600",
                          hasEntry && "bg-green-500 text-white font-bold hover:bg-green-600",
                          isToday && !hasEntry && "border-2 border-blue-500 dark:border-blue-400",
                          isToday && hasEntry && "ring-2 ring-blue-500 ring-offset-2 dark:ring-offset-gray-800",
                          !hasEntry && isCurrentMonth && "hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer"
                        )}
                      >
                        {isCurrentMonth && (
                          <span className="relative">
                            {dayNumber}
                            {hasEntry && (
                              <Check className="w-2 h-2 absolute -top-1 -right-1" />
                            )}
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Legend */}
              <div className="flex items-center gap-4 text-xs text-gray-600 dark:text-gray-400 pt-4 border-t border-gray-200 dark:border-gray-700">
                <div className="flex items-center gap-1.5">
                  <div className="w-4 h-4 bg-green-500 rounded"></div>
                  <span>Completed</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-4 h-4 border-2 border-blue-500 dark:border-blue-400 rounded"></div>
                  <span>Today</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Stats Card */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base lg:text-lg">Your Progress</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="text-center p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">24</div>
                  <div className="text-xs text-gray-600 dark:text-gray-400 mt-1">Total Entries</div>
                </div>
                <div className="text-center p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">5.2k</div>
                  <div className="text-xs text-gray-600 dark:text-gray-400 mt-1">Words Written</div>
                </div>
              </div>
              
              <div className="text-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                <div className="text-2xl font-bold text-green-600 dark:text-green-400">18</div>
                <div className="text-xs text-gray-600 dark:text-gray-400 mt-1">Days This Month</div>
              </div>

              <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
                <p className="text-xs text-gray-600 dark:text-gray-400 text-center">
                  Keep it up! You're building a great habit 🎉
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
