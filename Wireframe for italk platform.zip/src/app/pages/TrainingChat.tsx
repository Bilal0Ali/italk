import { useState } from "react";
import { Send, Brain, Sparkles, Info } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { ScrollArea } from "../components/ui/scroll-area";

interface Message {
  id: string;
  text: string;
  sender: "user" | "system";
  timestamp: string;
  learned?: string[];
}

export function TrainingChat() {
  const [messages] = useState<Message[]>([
    {
      id: "1",
      text: "Hi! I'm your AI training assistant. Let's help build your personality clone. Tell me about your day!",
      sender: "system",
      timestamp: "10:00 AM",
    },
    {
      id: "2",
      text: "Had a productive morning! Worked on some creative projects and then grabbed coffee with a friend. I tend to be more focused in the mornings.",
      sender: "user",
      timestamp: "10:02 AM",
      learned: ["Morning productivity preference", "Social interaction pattern"],
    },
    {
      id: "3",
      text: "That's great! I'm learning that you're productive in mornings and value social connections. How do you usually make decisions - do you think things through or go with your gut?",
      sender: "system",
      timestamp: "10:02 AM",
    },
    {
      id: "4",
      text: "I'm definitely a thinker. I like to analyze options and consider different perspectives before making important decisions. But for smaller stuff, I can be pretty spontaneous!",
      sender: "user",
      timestamp: "10:05 AM",
      learned: ["Analytical decision-making", "Situational flexibility"],
    },
  ]);

  const [inputValue, setInputValue] = useState("");

  const trainingMetrics = [
    { label: "Messages Today", value: "47" },
    { label: "Traits Learned", value: "12" },
    { label: "Accuracy", value: "82%" },
  ];

  return (
    <div className="h-full flex flex-col lg:flex-row">
      {/* Chat Area */}
      <div className="flex-1 flex flex-col min-h-0">
        <div className="border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 p-4 lg:p-6">
          <div className="flex items-center justify-between">
            <div className="flex-1 min-w-0">
              <h1 className="text-xl lg:text-2xl font-bold text-gray-900 dark:text-gray-100">Training Chat</h1>
              <p className="text-xs lg:text-sm text-gray-500 dark:text-gray-400 mt-1 truncate">Chat naturally to help your AI clone learn your personality</p>
            </div>
            <Badge className="bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 hover:bg-green-100 dark:hover:bg-green-900 ml-2 flex-shrink-0">
              <Brain className="w-3 h-3 mr-1" />
              <span className="hidden sm:inline">Learning</span>
            </Badge>
          </div>
        </div>

        <ScrollArea className="flex-1 p-4 lg:p-6 bg-gray-50 dark:bg-gray-900">
          <div className="max-w-3xl mx-auto space-y-4">
            {messages.map((message) => (
              <div key={message.id}>
                <div
                  className={`flex ${
                    message.sender === "user" ? "justify-end" : "justify-start"
                  }`}
                >
                  <div
                    className={`max-w-[85%] lg:max-w-md rounded-lg px-3 lg:px-4 py-2 lg:py-3 ${
                      message.sender === "user"
                        ? "bg-blue-600 text-white"
                        : "bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-gray-100"
                    }`}
                  >
                    <p className="text-xs lg:text-sm">{message.text}</p>
                    <p
                      className={`text-xs mt-1 lg:mt-2 ${
                        message.sender === "user" ? "text-blue-100" : "text-gray-400 dark:text-gray-500"
                      }`}
                    >
                      {message.timestamp}
                    </p>
                  </div>
                </div>
                
                {message.learned && message.learned.length > 0 && (
                  <div className="flex justify-end mt-2">
                    <div className="max-w-[85%] lg:max-w-md bg-purple-50 dark:bg-purple-900/30 border border-purple-200 dark:border-purple-800 rounded-lg px-3 lg:px-4 py-2">
                      <div className="flex items-center gap-2 mb-2">
                        <Sparkles className="w-3 h-3 text-purple-600 dark:text-purple-400" />
                        <span className="text-xs font-medium text-purple-900 dark:text-purple-300">Clone Learned:</span>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {message.learned.map((trait, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs bg-white dark:bg-gray-800 border-purple-300 dark:border-purple-700 text-purple-700 dark:text-purple-300">
                            {trait}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </ScrollArea>

        <div className="border-t border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 p-4 lg:p-6">
          <div className="max-w-3xl mx-auto">
            <div className="flex gap-2 lg:gap-3">
              <Input
                placeholder="Type your message..."
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                className="flex-1 h-11 lg:h-9 text-sm"
              />
              <Button className="bg-blue-600 hover:bg-blue-700 h-11 w-11 lg:h-9 lg:w-auto px-3">
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Right Sidebar - Hidden on mobile, shown in modal or separate view */}
      <aside className="hidden lg:block w-80 border-l border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 p-6">
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-lg">Training Progress</CardTitle>
            <CardDescription>Today's metrics</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {trainingMetrics.map((metric) => (
              <div key={metric.label} className="flex justify-between items-center">
                <span className="text-sm text-gray-600">{metric.label}</span>
                <span className="text-lg font-bold text-gray-900">{metric.value}</span>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Info className="w-4 h-4" />
              Training Tips
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3 text-sm text-gray-600">
              <li className="flex gap-2">
                <span className="text-blue-600">•</span>
                <span>Be authentic and conversational</span>
              </li>
              <li className="flex gap-2">
                <span className="text-blue-600">•</span>
                <span>Share your thoughts and decision-making process</span>
              </li>
              <li className="flex gap-2">
                <span className="text-blue-600">•</span>
                <span>Discuss your preferences and values</span>
              </li>
              <li className="flex gap-2">
                <span className="text-blue-600">•</span>
                <span>The more you chat, the smarter your clone becomes</span>
              </li>
            </ul>
          </CardContent>
        </Card>
      </aside>
    </div>
  );
}