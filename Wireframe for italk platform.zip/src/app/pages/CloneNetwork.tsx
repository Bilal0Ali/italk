import { Users, MessageSquare, Brain, Search, UserPlus } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Avatar, AvatarFallback } from "../components/ui/avatar";

export function CloneNetwork() {
  const connectedClones = [
    {
      name: "Alex Chen",
      initials: "AC",
      color: "from-green-500 to-teal-500",
      status: "active",
      compatibility: 87,
      sharedInterests: ["Technology", "Reading", "Coffee"],
      conversationCount: 156,
      description: "Creative problem-solver with analytical mindset. Enjoys tech discussions.",
    },
    {
      name: "Sarah Johnson",
      initials: "SJ",
      color: "from-pink-500 to-rose-500",
      status: "active",
      compatibility: 92,
      sharedInterests: ["Creative Projects", "Philosophy", "Design"],
      conversationCount: 203,
      description: "Empathetic communicator with passion for creative work and deep conversations.",
    },
    {
      name: "Michael Brown",
      initials: "MB",
      color: "from-orange-500 to-yellow-500",
      status: "idle",
      compatibility: 76,
      sharedInterests: ["Sports", "Entrepreneurship"],
      conversationCount: 84,
      description: "Decisive leader with entrepreneurial spirit. Action-oriented thinker.",
    },
  ];

  const suggestedClones = [
    {
      name: "Emma Wilson",
      initials: "EW",
      color: "from-purple-500 to-indigo-500",
      compatibility: 89,
      sharedInterests: ["Technology", "Travel", "Photography"],
      mutualConnections: 5,
    },
    {
      name: "David Lee",
      initials: "DL",
      color: "from-blue-500 to-cyan-500",
      compatibility: 81,
      sharedInterests: ["Reading", "Writing", "Philosophy"],
      mutualConnections: 3,
    },
  ];

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">Clone Network</h1>
        <p className="text-gray-500 dark:text-gray-400 mt-1">Connect your AI clone with other personality clones</p>
      </div>

      {/* Search Bar */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <Input placeholder="Search for clones by name, interests, or traits..." className="pl-10" />
            </div>
            <Button variant="outline">
              <Users className="w-4 h-4 mr-2" />
              Filter
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Connected Clones</CardTitle>
            <Users className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">24</div>
            <p className="text-xs text-gray-500 mt-2">12 active conversations</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Conversations</CardTitle>
            <MessageSquare className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">847</div>
            <p className="text-xs text-gray-500 mt-2">+34 this week</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Compatibility</CardTitle>
            <Brain className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">82%</div>
            <p className="text-xs text-gray-500 mt-2">Based on shared traits</p>
          </CardContent>
        </Card>
      </div>

      {/* Connected Clones */}
      <div className="mb-8">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Your Connected Clones</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {connectedClones.map((clone) => (
            <Card key={clone.name}>
              <CardContent className="pt-6">
                <div className="flex items-start gap-4">
                  <div className={`w-16 h-16 rounded-full bg-gradient-to-br ${clone.color} flex items-center justify-center text-white text-xl font-bold`}>
                    {clone.initials}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-bold text-gray-900">{clone.name}</h3>
                      <Badge className={
                        clone.status === 'active'
                          ? 'bg-green-100 text-green-700 hover:bg-green-100'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-100'
                      }>
                        {clone.status}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600 mb-3">{clone.description}</p>
                    
                    <div className="flex items-center gap-4 mb-3 text-sm text-gray-500">
                      <div className="flex items-center gap-1">
                        <Brain className="w-4 h-4" />
                        <span>{clone.compatibility}% match</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <MessageSquare className="w-4 h-4" />
                        <span>{clone.conversationCount} chats</span>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2 mb-3">
                      {clone.sharedInterests.map((interest) => (
                        <Badge key={interest} variant="outline" className="text-xs">
                          {interest}
                        </Badge>
                      ))}
                    </div>

                    <Button size="sm" variant="outline" className="w-full">
                      <MessageSquare className="w-4 h-4 mr-2" />
                      View Conversations
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Suggested Connections */}
      <div>
        <h2 className="text-xl font-bold text-gray-900 mb-4">Suggested Connections</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {suggestedClones.map((clone) => (
            <Card key={clone.name}>
              <CardContent className="pt-6">
                <div className="flex items-start gap-4">
                  <div className={`w-16 h-16 rounded-full bg-gradient-to-br ${clone.color} flex items-center justify-center text-white text-xl font-bold`}>
                    {clone.initials}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-gray-900 mb-2">{clone.name}</h3>
                    
                    <div className="flex items-center gap-4 mb-3 text-sm text-gray-500">
                      <div className="flex items-center gap-1">
                        <Brain className="w-4 h-4" />
                        <span>{clone.compatibility}% compatible</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Users className="w-4 h-4" />
                        <span>{clone.mutualConnections} mutual</span>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2 mb-3">
                      {clone.sharedInterests.map((interest) => (
                        <Badge key={interest} variant="outline" className="text-xs">
                          {interest}
                        </Badge>
                      ))}
                    </div>

                    <Button size="sm" className="w-full bg-blue-600 hover:bg-blue-700">
                      <UserPlus className="w-4 h-4 mr-2" />
                      Connect Clones
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}