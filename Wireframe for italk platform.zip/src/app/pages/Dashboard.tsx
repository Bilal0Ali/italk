import { Brain, MessageSquare, Users, TrendingUp, Activity, Zap } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Progress } from "../components/ui/progress";
import { Badge } from "../components/ui/badge";
import { Button } from "../components/ui/button";

export function Dashboard() {
  const cloneStats = [
    { label: "Training Progress", value: 67, color: "bg-blue-500" },
    { label: "Tone Accuracy", value: 82, color: "bg-green-500" },
    { label: "Decision Consistency", value: 74, color: "bg-purple-500" },
    { label: "Communication Style", value: 89, color: "bg-orange-500" },
  ];

  const recentActivity = [
    { action: "Clone conversation with Alex's clone", time: "2 hours ago", type: "conversation" },
    { action: "Training session completed", time: "5 hours ago", type: "training" },
    { action: "Personality trait updated: Humor", time: "1 day ago", type: "update" },
    { action: "Connected with 3 new clones", time: "2 days ago", type: "network" },
  ];

  return (
    <div className="p-4 lg:p-8">
      <div className="mb-6 lg:mb-8">
        <h1 className="text-2xl lg:text-3xl font-bold text-gray-900 dark:text-gray-100">Dashboard</h1>
        <p className="text-sm lg:text-base text-gray-500 dark:text-gray-400 mt-1">Welcome back! Your AI clone is actively learning.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-6 mb-6 lg:mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs lg:text-sm font-medium">Clone Status</CardTitle>
            <Brain className="h-4 w-4 text-blue-600 dark:text-blue-400" />
          </CardHeader>
          <CardContent>
            <div className="text-xl lg:text-2xl font-bold">Active</div>
            <Badge className="mt-2 bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 hover:bg-green-100 dark:hover:bg-green-900 text-xs">Learning</Badge>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs lg:text-sm font-medium">Messages</CardTitle>
            <MessageSquare className="h-4 w-4 text-purple-600 dark:text-purple-400" />
          </CardHeader>
          <CardContent>
            <div className="text-xl lg:text-2xl font-bold">1,247</div>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">+89 this week</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs lg:text-sm font-medium">Connections</CardTitle>
            <Users className="h-4 w-4 text-green-600 dark:text-green-400" />
          </CardHeader>
          <CardContent>
            <div className="text-xl lg:text-2xl font-bold">24</div>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">12 active</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs lg:text-sm font-medium">Accuracy</CardTitle>
            <TrendingUp className="h-4 w-4 text-orange-600 dark:text-orange-400" />
          </CardHeader>
          <CardContent>
            <div className="text-xl lg:text-2xl font-bold">78%</div>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">↑ 12%</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:gap-6">
        {/* Clone Development */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base lg:text-lg">
              <Zap className="w-4 h-4 lg:w-5 lg:h-5 text-blue-600 dark:text-blue-400" />
              Clone Development
            </CardTitle>
            <CardDescription className="text-xs lg:text-sm">Your AI personality clone learning progress</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 lg:space-y-6">
            {cloneStats.map((stat) => (
              <div key={stat.label}>
                <div className="flex justify-between mb-2">
                  <span className="text-xs lg:text-sm font-medium text-gray-700 dark:text-gray-300">{stat.label}</span>
                  <span className="text-xs lg:text-sm font-bold text-gray-900 dark:text-gray-100">{stat.value}%</span>
                </div>
                <Progress value={stat.value} className="h-2" />
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base lg:text-lg">
              <Activity className="w-4 h-4 lg:w-5 lg:h-5 text-purple-600 dark:text-purple-400" />
              Recent Activity
            </CardTitle>
            <CardDescription className="text-xs lg:text-sm">Latest updates and interactions</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 lg:space-y-4">
              {recentActivity.map((activity, index) => (
                <div key={index} className="flex items-start gap-3 pb-3 lg:pb-4 border-b border-gray-100 dark:border-gray-700 last:border-0 last:pb-0">
                  <div className={`w-2 h-2 rounded-full mt-1.5 lg:mt-2 flex-shrink-0 ${
                    activity.type === 'conversation' ? 'bg-blue-500' :
                    activity.type === 'training' ? 'bg-green-500' :
                    activity.type === 'update' ? 'bg-purple-500' :
                    'bg-orange-500'
                  }`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs lg:text-sm text-gray-900 dark:text-gray-100">{activity.action}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card className="mt-4 lg:mt-6">
        <CardHeader>
          <CardTitle className="text-base lg:text-lg">Quick Actions</CardTitle>
          <CardDescription className="text-xs lg:text-sm">Continue building your AI clone</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col lg:flex-row gap-3">
            <Button className="bg-blue-600 hover:bg-blue-700 h-11 lg:h-9 text-sm">
              <MessageSquare className="w-4 h-4 mr-2" />
              Start Training Session
            </Button>
            <Button variant="outline" className="h-11 lg:h-9 text-sm">
              <Users className="w-4 h-4 mr-2" />
              Browse Clone Network
            </Button>
            <Button variant="outline" className="h-11 lg:h-9 text-sm">
              <Brain className="w-4 h-4 mr-2" />
              View Clone Profile
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}