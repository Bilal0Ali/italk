import { Brain, MessageSquare, Target, Heart, Zap, TrendingUp, Edit } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Progress } from "../components/ui/progress";
import { Badge } from "../components/ui/badge";
import { Button } from "../components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";

export function MyClone() {
  const personalityTraits = [
    { trait: "Analytical Thinking", strength: 85, icon: Brain, color: "text-blue-600" },
    { trait: "Empathy", strength: 78, icon: Heart, color: "text-pink-600" },
    { trait: "Decisiveness", strength: 72, icon: Target, color: "text-green-600" },
    { trait: "Enthusiasm", strength: 68, icon: Zap, color: "text-yellow-600" },
  ];

  const communicationPatterns = [
    { pattern: "Casual & Friendly", score: 92 },
    { pattern: "Uses Humor", score: 76 },
    { pattern: "Asks Questions", score: 84 },
    { pattern: "Detailed Explanations", score: 81 },
  ];

  const decisionStyles = [
    { style: "Analytical", percentage: 65 },
    { style: "Intuitive", percentage: 25 },
    { style: "Collaborative", percentage: 10 },
  ];

  const learnedPreferences = [
    { category: "Communication", items: ["Morning productivity", "Prefers text over calls", "Responds quickly"] },
    { category: "Social", items: ["Small gatherings over large events", "Values deep conversations", "Close-knit friend group"] },
    { category: "Work Style", items: ["Structured approach", "Creative problem-solving", "Independent worker"] },
    { category: "Interests", items: ["Technology", "Reading", "Coffee culture", "Creative projects"] },
  ];

  return (
    <div className="p-8">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">My AI Clone</h1>
            <p className="text-gray-500 dark:text-gray-400 mt-1">Your digital personality profile</p>
          </div>
          <Button variant="outline">
            <Edit className="w-4 h-4 mr-2" />
            Edit Clone Settings
          </Button>
        </div>
      </div>

      {/* Clone Profile Header */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex items-start gap-6">
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 flex items-center justify-center text-white text-3xl font-bold">
              JD
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">John Doe's Clone</h2>
                <Badge className="bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 hover:bg-green-100 dark:hover:bg-green-900">Active</Badge>
              </div>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                Analytical thinker with a friendly communication style. Enjoys deep conversations and creative problem-solving. 
                Active learner with strong morning productivity patterns.
              </p>
              <div className="flex gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-gray-900 dark:text-gray-100">1,247</div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">Training Messages</div>
                </div>
                <div className="border-l border-gray-200 dark:border-gray-700 pl-4 text-center">
                  <div className="text-2xl font-bold text-gray-900 dark:text-gray-100">78%</div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">Accuracy Score</div>
                </div>
                <div className="border-l border-gray-200 dark:border-gray-700 pl-4 text-center">
                  <div className="text-2xl font-bold text-gray-900 dark:text-gray-100">24</div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">Clone Connections</div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="personality" className="space-y-6">
        <TabsList>
          <TabsTrigger value="personality">Personality Traits</TabsTrigger>
          <TabsTrigger value="communication">Communication</TabsTrigger>
          <TabsTrigger value="decisions">Decision Style</TabsTrigger>
          <TabsTrigger value="preferences">Preferences</TabsTrigger>
        </TabsList>

        <TabsContent value="personality" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {personalityTraits.map((item) => {
              const Icon = item.icon;
              return (
                <Card key={item.trait}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Icon className={`w-5 h-5 ${item.color}`} />
                      {item.trait}
                    </CardTitle>
                    <CardDescription>Learned strength level</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-4">
                      <Progress value={item.strength} className="flex-1 h-3" />
                      <span className="text-lg font-bold text-gray-900">{item.strength}%</span>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="communication">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-purple-600" />
                Communication Patterns
              </CardTitle>
              <CardDescription>How your clone communicates based on learned patterns</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {communicationPatterns.map((pattern) => (
                <div key={pattern.pattern}>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm font-medium text-gray-700">{pattern.pattern}</span>
                    <span className="text-sm font-bold text-gray-900">{pattern.score}%</span>
                  </div>
                  <Progress value={pattern.score} className="h-2" />
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="decisions">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5 text-green-600" />
                Decision-Making Style
              </CardTitle>
              <CardDescription>How your clone approaches decisions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {decisionStyles.map((style) => (
                  <div key={style.style}>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium text-gray-700">{style.style}</span>
                      <span className="text-sm font-bold text-gray-900">{style.percentage}%</span>
                    </div>
                    <div className="h-4 bg-gray-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-green-500 to-blue-500 rounded-full"
                        style={{ width: `${style.percentage}%` }}
                      />
                    </div>
                  </div>
                ))}
                
                <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <p className="text-sm text-gray-700">
                    <strong>Analysis:</strong> Your clone tends to make decisions analytically, carefully weighing options 
                    and considering multiple perspectives. This approach is balanced with occasional intuitive decisions 
                    in familiar situations.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="preferences">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {learnedPreferences.map((pref) => (
              <Card key={pref.category}>
                <CardHeader>
                  <CardTitle>{pref.category}</CardTitle>
                  <CardDescription>Learned preferences from conversations</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {pref.items.map((item, idx) => (
                      <div key={idx} className="flex items-center gap-2">
                        <TrendingUp className="w-3 h-3 text-blue-600" />
                        <span className="text-sm text-gray-700">{item}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}