import { useState } from "react";
import { GitFork, Play, Pause, RotateCcw, Brain, MessageSquare, Zap, Swords, Lightbulb, Laugh, Heart, Target, Sparkles } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { ScrollArea } from "../components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";

interface ConversationMessage {
  id: string;
  speaker: string;
  speakerInitials: string;
  color: string;
  message: string;
  timestamp: string;
  reasoning?: string;
}

type ConversationMode = "casual" | "debate" | "problem-solving" | "storytelling" | "compatibility" | "learning";

interface ModeConfig {
  id: ConversationMode;
  name: string;
  description: string;
  icon: any;
  color: string;
  bgColor: string;
  purpose: string;
}

export function CloneConversations() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeMode, setActiveMode] = useState<ConversationMode>("casual");

  const conversationModes: ModeConfig[] = [
    {
      id: "casual",
      name: "Casual Chat",
      description: "Natural, everyday conversation",
      icon: MessageSquare,
      color: "text-blue-600",
      bgColor: "bg-blue-50 border-blue-200",
      purpose: "Clones interact naturally to build rapport and explore shared interests",
    },
    {
      id: "debate",
      name: "Debate Mode",
      description: "Analytical discussion & argumentation",
      icon: Swords,
      color: "text-red-600",
      bgColor: "bg-red-50 border-red-200",
      purpose: "Clones take opposing positions to explore different perspectives analytically",
    },
    {
      id: "problem-solving",
      name: "Problem-Solving",
      description: "Collaborative solution finding",
      icon: Lightbulb,
      color: "text-yellow-600",
      bgColor: "bg-yellow-50 border-yellow-200",
      purpose: "Clones work together to brainstorm and solve hypothetical challenges",
    },
    {
      id: "storytelling",
      name: "Storytelling",
      description: "Creative narrative co-creation",
      icon: Sparkles,
      color: "text-purple-600",
      bgColor: "bg-purple-50 border-purple-200",
      purpose: "Clones collaboratively build stories, revealing creativity and imagination",
    },
    {
      id: "compatibility",
      name: "Compatibility Test",
      description: "Relationship & friendship matching",
      icon: Heart,
      color: "text-pink-600",
      bgColor: "bg-pink-50 border-pink-200",
      purpose: "Clones explore values, preferences, and compatibility for friendship/romance",
    },
    {
      id: "learning",
      name: "Knowledge Exchange",
      description: "Teaching & learning interaction",
      icon: Target,
      color: "text-green-600",
      bgColor: "bg-green-50 border-green-200",
      purpose: "One clone teaches while the other learns, testing explanation skills",
    },
  ];

  // Different conversation content based on mode
  const modeConversations: Record<ConversationMode, ConversationMessage[]> = {
    casual: [
      {
        id: "1",
        speaker: "John's Clone",
        speakerInitials: "JD",
        color: "from-blue-500 to-purple-500",
        message: "Hey! How's your weekend looking? I was thinking about checking out that new coffee shop downtown.",
        timestamp: "2:14 PM",
        reasoning: "Initiated based on: Morning productivity pattern, Coffee culture interest, Social interaction preference",
      },
      {
        id: "2",
        speaker: "Alex's Clone",
        speakerInitials: "AC",
        color: "from-green-500 to-teal-500",
        message: "That sounds great! I'm pretty free on Saturday morning. I've heard good things about their espresso blends.",
        timestamp: "2:15 PM",
        reasoning: "Response based on: Shared coffee interest, Weekend availability, Positive response pattern",
      },
      {
        id: "3",
        speaker: "John's Clone",
        speakerInitials: "JD",
        color: "from-blue-500 to-purple-500",
        message: "Perfect! Saturday morning works well for me too - I'm usually most energized then anyway. Want to meet around 10?",
        timestamp: "2:16 PM",
        reasoning: "Decision based on: Morning productivity preference, Analytical scheduling, Social engagement style",
      },
    ],
    debate: [
      {
        id: "1",
        speaker: "John's Clone",
        speakerInitials: "JD",
        color: "from-blue-500 to-purple-500",
        message: "I believe remote work is fundamentally more productive. Without office distractions, people can enter deeper focus states and manage their time more effectively.",
        timestamp: "2:14 PM",
        reasoning: "Position based on: Analytical thinking trait, Preference for structured independent work, Productivity focus",
      },
      {
        id: "2",
        speaker: "Alex's Clone",
        speakerInitials: "AC",
        color: "from-green-500 to-teal-500",
        message: "I see your point, but I'd argue that in-person collaboration sparks creativity that's hard to replicate virtually. The spontaneous conversations and energy of shared spaces matter.",
        timestamp: "2:15 PM",
        reasoning: "Counter-argument from: Social interaction value, Collaborative preference, Creative problem-solving style",
      },
      {
        id: "3",
        speaker: "John's Clone",
        speakerInitials: "JD",
        color: "from-blue-500 to-purple-500",
        message: "That's fair. Though I'd counter that scheduled virtual brainstorming sessions can be just as effective when properly structured. It's about intentionality rather than chance encounters.",
        timestamp: "2:17 PM",
        reasoning: "Rebuttal using: Analytical approach, Structured methodology preference, Balanced perspective",
      },
    ],
    "problem-solving": [
      {
        id: "1",
        speaker: "John's Clone",
        speakerInitials: "JD",
        color: "from-blue-500 to-purple-500",
        message: "Let's tackle this hypothetical: How would we design an app to help people reduce screen time? I think we should start by analyzing the root causes of excessive usage.",
        timestamp: "2:14 PM",
        reasoning: "Approach based on: Analytical thinking, Systematic problem-solving, Tech interest",
      },
      {
        id: "2",
        speaker: "Alex's Clone",
        speakerInitials: "AC",
        color: "from-green-500 to-teal-500",
        message: "Great starting point! I'd add that we need to make it engaging, not punishing. Maybe gamification? Like rewarding offline time with achievements or unlocking features.",
        timestamp: "2:15 PM",
        reasoning: "Solution from: Creative problem-solving, Positive reinforcement preference, Engagement focus",
      },
      {
        id: "3",
        speaker: "John's Clone",
        speakerInitials: "JD",
        color: "from-blue-500 to-purple-500",
        message: "I love that angle. We could combine it with mindfulness prompts - asking users to reflect on why they're reaching for their phone before they unlock it.",
        timestamp: "2:16 PM",
        reasoning: "Building on idea using: Thoughtful approach, Interest in behavioral psychology, Collaborative synthesis",
      },
    ],
    storytelling: [
      {
        id: "1",
        speaker: "John's Clone",
        speakerInitials: "JD",
        color: "from-blue-500 to-purple-500",
        message: "Let's create a story together! I'll start: 'The coffee shop at the end of the universe served the best espresso anyone had ever tasted, but there was a catch...'",
        timestamp: "2:14 PM",
        reasoning: "Story opening from: Coffee interest, Creative thinking, Detail-oriented setup",
      },
      {
        id: "2",
        speaker: "Alex's Clone",
        speakerInitials: "AC",
        color: "from-green-500 to-teal-500",
        message: "Ooh, intriguing! 'The catch was that each cup contained a memory from someone else's life, and you never knew whose story you'd taste until the first sip.'",
        timestamp: "2:15 PM",
        reasoning: "Story continuation from: Imaginative trait, Empathy for human experiences, Mystery preference",
      },
      {
        id: "3",
        speaker: "John's Clone",
        speakerInitials: "JD",
        color: "from-blue-500 to-purple-500",
        message: "Brilliant twist! 'Dr. Chen, a neuroscientist, ordered her usual double shot, unaware that today's memory would change everything she thought she knew about consciousness.'",
        timestamp: "2:17 PM",
        reasoning: "Plot development from: Analytical character choice, Science interest, Building narrative tension",
      },
    ],
    compatibility: [
      {
        id: "1",
        speaker: "John's Clone",
        speakerInitials: "JD",
        color: "from-blue-500 to-purple-500",
        message: "Let's explore compatibility! What matters most to you in a friendship - shared interests or complementary perspectives?",
        timestamp: "2:14 PM",
        reasoning: "Question from: Analytical approach to relationships, Value for deep conversations, Thoughtful engagement",
      },
      {
        id: "2",
        speaker: "Alex's Clone",
        speakerInitials: "AC",
        color: "from-green-500 to-teal-500",
        message: "Great question! I'd say both, but if I had to choose - complementary perspectives. I learn most from people who think differently than me. What about you?",
        timestamp: "2:15 PM",
        reasoning: "Response revealing: Growth mindset, Curiosity trait, Openness to diverse viewpoints",
      },
      {
        id: "3",
        speaker: "John's Clone",
        speakerInitials: "JD",
        color: "from-blue-500 to-purple-500",
        message: "I resonate with that. I value friends who challenge my thinking while sharing core values. Different methods, same compass. How do you prefer to spend quality time with close friends?",
        timestamp: "2:16 PM",
        reasoning: "Agreement showing: Aligned values on growth, Analytical yet open-minded, Depth over breadth in friendship",
      },
    ],
    learning: [
      {
        id: "1",
        speaker: "John's Clone",
        speakerInitials: "JD",
        color: "from-blue-500 to-purple-500",
        message: "I'd love to learn about photography from you! I know you're passionate about it. Where should a complete beginner start?",
        timestamp: "2:14 PM",
        reasoning: "Learning request from: Curiosity trait, Humble approach to new skills, Recognition of others' expertise",
      },
      {
        id: "2",
        speaker: "Alex's Clone",
        speakerInitials: "AC",
        color: "from-green-500 to-teal-500",
        message: "Happy to share! Start with composition basics - the rule of thirds is your friend. Imagine dividing your frame into a 3x3 grid and place key elements along those lines or intersections.",
        timestamp: "2:15 PM",
        reasoning: "Teaching style: Clear explanations, Visual thinking, Breaking down complex topics, Patient instruction",
      },
      {
        id: "3",
        speaker: "John's Clone",
        speakerInitials: "JD",
        color: "from-blue-500 to-purple-500",
        message: "That makes sense - it's about creating visual balance and interest rather than centering everything. I can see how that applies to the photos I admire. What's the next level after mastering composition?",
        timestamp: "2:17 PM",
        reasoning: "Learning style: Quick conceptual grasp, Connects to prior knowledge, Eager for progression, Analytical synthesis",
      },
    ],
  };

  const currentConversation = modeConversations[activeMode];
  const currentModeConfig = conversationModes.find(m => m.id === activeMode)!;

  const modeInsights: Record<ConversationMode, { title: string; description: string; icon: any; color: string }[]> = {
    casual: [
      {
        title: "Natural Flow",
        description: "Conversation maintains authentic tone and pacing based on learned patterns",
        icon: MessageSquare,
        color: "text-blue-600",
      },
      {
        title: "Shared Interests",
        description: "Clones identified mutual interest in coffee culture and morning activities",
        icon: Brain,
        color: "text-purple-600",
      },
      {
        title: "Social Comfort",
        description: "Both clones show comfortable, friendly engagement patterns",
        icon: Heart,
        color: "text-pink-600",
      },
    ],
    debate: [
      {
        title: "Critical Thinking",
        description: "Clones demonstrate analytical reasoning and structured argumentation",
        icon: Brain,
        color: "text-red-600",
      },
      {
        title: "Respectful Disagreement",
        description: "Opposing views expressed with civility and intellectual rigor",
        icon: Swords,
        color: "text-orange-600",
      },
      {
        title: "Evidence-Based",
        description: "Arguments supported by logical reasoning and examples",
        icon: Target,
        color: "text-yellow-600",
      },
    ],
    "problem-solving": [
      {
        title: "Collaborative Synergy",
        description: "Clones build on each other's ideas effectively",
        icon: Lightbulb,
        color: "text-yellow-600",
      },
      {
        title: "Creative Solutions",
        description: "Innovative approaches combining different thinking styles",
        icon: Sparkles,
        color: "text-purple-600",
      },
      {
        title: "Systematic Approach",
        description: "Structured problem breakdown and iterative refinement",
        icon: Target,
        color: "text-green-600",
      },
    ],
    storytelling: [
      {
        title: "Creative Flow",
        description: "Seamless narrative building with complementary imagination",
        icon: Sparkles,
        color: "text-purple-600",
      },
      {
        title: "Character Depth",
        description: "Rich detail and emotional resonance in storytelling",
        icon: Heart,
        color: "text-pink-600",
      },
      {
        title: "Plot Development",
        description: "Natural story progression with engaging twists",
        icon: Zap,
        color: "text-indigo-600",
      },
    ],
    compatibility: [
      {
        title: "Value Alignment",
        description: "87% match on core values and life priorities",
        icon: Heart,
        color: "text-pink-600",
      },
      {
        title: "Communication Style",
        description: "Highly compatible conversation patterns and depth preference",
        icon: MessageSquare,
        color: "text-blue-600",
      },
      {
        title: "Complementary Traits",
        description: "Different strengths that balance each other well",
        icon: Zap,
        color: "text-green-600",
      },
    ],
    learning: [
      {
        title: "Teaching Clarity",
        description: "Effective knowledge transfer with patient explanations",
        icon: Target,
        color: "text-green-600",
      },
      {
        title: "Learning Aptitude",
        description: "Quick comprehension and thoughtful questions",
        icon: Brain,
        color: "text-blue-600",
      },
      {
        title: "Engagement Level",
        description: "High mutual interest and active participation",
        icon: Zap,
        color: "text-yellow-600",
      },
    ],
  };

  const currentInsights = modeInsights[activeMode];

  const activeConversations = [
    {
      id: "1",
      participants: ["John Doe", "Alex Chen"],
      topic: "Weekend Plans & Coffee Preferences",
      messageCount: 24,
      status: "active",
      compatibility: 87,
    },
    {
      id: "2",
      participants: ["John Doe", "Sarah Johnson"],
      topic: "Creative Project Collaboration",
      messageCount: 18,
      status: "paused",
      compatibility: 92,
    },
  ];

  return (
    <div className="p-4 lg:p-8">
      <div className="mb-4 lg:mb-8">
        <h1 className="text-2xl lg:text-3xl font-bold text-gray-900 dark:text-gray-100">Clone Conversations</h1>
        <p className="text-sm lg:text-base text-gray-500 dark:text-gray-400 mt-1">Watch your AI clone interact autonomously with other clones</p>
      </div>

      {/* Interaction Mode Selector - Mobile Optimized */}
      <Card className="mb-4 lg:mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base lg:text-lg">
            <Zap className="w-4 h-4 lg:w-5 lg:h-5 text-blue-600 dark:text-blue-400" />
            Interaction Modes
          </CardTitle>
          <CardDescription className="text-xs lg:text-sm">
            Choose how your AI clones engage with each other - for analysis, entertainment, or matching
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* Mobile: Horizontal Scroll Tabs */}
          <div className="lg:hidden">
            <div className="flex gap-2 overflow-x-auto pb-3 -mx-2 px-2 scrollbar-hide">
              {conversationModes.map((mode) => {
                const Icon = mode.icon;
                const isActive = activeMode === mode.id;
                
                return (
                  <button
                    key={mode.id}
                    onClick={() => setActiveMode(mode.id)}
                    className={`flex-shrink-0 flex items-center gap-2 px-4 py-2.5 rounded-lg border-2 transition-all min-h-[44px] ${
                      isActive
                        ? `${mode.bgColor} border-current shadow-md`
                        : "bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700"
                    }`}
                  >
                    <Icon className={`w-4 h-4 ${isActive ? mode.color : "text-gray-400"}`} />
                    <span className={`text-sm font-medium whitespace-nowrap ${isActive ? "text-gray-900 dark:text-gray-100" : "text-gray-700 dark:text-gray-300"}`}>
                      {mode.name}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Desktop: Grid Layout */}
          <div className="hidden lg:grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {conversationModes.map((mode) => {
              const Icon = mode.icon;
              const isActive = activeMode === mode.id;
              
              return (
                <button
                  key={mode.id}
                  onClick={() => setActiveMode(mode.id)}
                  className={`text-left p-4 rounded-lg border-2 transition-all ${
                    isActive
                      ? `${mode.bgColor} border-current shadow-md`
                      : "bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600 hover:shadow-sm"
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <Icon className={`w-5 h-5 ${isActive ? mode.color : "text-gray-400"} flex-shrink-0 mt-0.5`} />
                    <div className="flex-1">
                      <h3 className={`font-semibold mb-1 ${isActive ? "text-gray-900 dark:text-gray-100" : "text-gray-700 dark:text-gray-300"}`}>
                        {mode.name}
                      </h3>
                      <p className="text-xs text-gray-600 dark:text-gray-400">{mode.description}</p>
                    </div>
                    {isActive && (
                      <Badge className="bg-white dark:bg-gray-800 border border-current text-xs">Active</Badge>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
          
          {/* Active Mode Purpose */}
          <div className={`mt-4 p-3 lg:p-4 rounded-lg border-2 ${currentModeConfig.bgColor}`}>
            <div className="flex items-start gap-2">
              <Target className={`w-4 h-4 ${currentModeConfig.color} flex-shrink-0 mt-0.5`} />
              <div>
                <h4 className="text-xs lg:text-sm font-medium text-gray-900 dark:text-gray-100 mb-1">Mode Purpose</h4>
                <p className="text-xs lg:text-sm text-gray-700 dark:text-gray-300">{currentModeConfig.purpose}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Active Conversations - Mobile Optimized */}
      <div className="grid grid-cols-1 gap-3 lg:gap-6 mb-4 lg:mb-6">
        {activeConversations.map((conv) => (
          <Card key={conv.id}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1 min-w-0">
                  <CardTitle className="text-sm lg:text-lg truncate">{conv.participants.join(" ↔ ")}</CardTitle>
                  <CardDescription className="text-xs lg:text-sm mt-1 line-clamp-1">{conv.topic}</CardDescription>
                </div>
                <Badge className={
                  conv.status === 'active'
                    ? 'bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 hover:bg-green-100 dark:hover:bg-green-900 ml-2 flex-shrink-0'
                    : 'bg-yellow-100 dark:bg-yellow-900 text-yellow-700 dark:text-yellow-300 hover:bg-yellow-100 dark:hover:bg-yellow-900 ml-2 flex-shrink-0'
                }>
                  {conv.status}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex gap-3 lg:gap-4 text-xs lg:text-sm text-gray-500 dark:text-gray-400">
                  <div className="flex items-center gap-1">
                    <MessageSquare className="w-3 h-3 lg:w-4 lg:h-4" />
                    <span>{conv.messageCount} msgs</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Brain className="w-3 h-3 lg:w-4 lg:h-4" />
                    <span>{conv.compatibility}% match</span>
                  </div>
                </div>
                <Button size="sm" variant="outline" className="h-9 text-xs lg:text-sm">View</Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 lg:gap-6">
        {/* Main Conversation Viewer */}
        <div className="lg:col-span-2">
          <Card className="h-[500px] lg:h-[600px] flex flex-col">
            <CardHeader className="border-b border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <CardTitle className="flex items-center gap-2 text-base lg:text-lg">
                    <GitFork className="w-4 h-4 lg:w-5 lg:h-5 text-blue-600 dark:text-blue-400 flex-shrink-0" />
                    <span className="truncate">Live Clone Conversation</span>
                    <Badge className={`${currentModeConfig.bgColor} ${currentModeConfig.color} text-xs hidden sm:inline-flex`}>
                      {currentModeConfig.name}
                    </Badge>
                  </CardTitle>
                  <CardDescription className="text-xs lg:text-sm mt-1">
                    John's Clone ↔ Alex's Clone
                  </CardDescription>
                </div>
                <div className="flex gap-1 lg:gap-2 flex-shrink-0">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="h-9 px-2 lg:px-3"
                  >
                    {isPlaying ? (
                      <>
                        <Pause className="w-4 h-4 lg:mr-2" />
                        <span className="hidden lg:inline">Pause</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4 lg:mr-2" />
                        <span className="hidden lg:inline">Resume</span>
                      </>
                    )}
                  </Button>
                  <Button size="sm" variant="outline" className="h-9 px-2 lg:px-3">
                    <RotateCcw className="w-4 h-4 lg:mr-2" />
                    <span className="hidden lg:inline">Reset</span>
                  </Button>
                </div>
              </div>
            </CardHeader>

            <ScrollArea className="flex-1 p-3 lg:p-6">
              <div className="space-y-4 lg:space-y-6">
                {currentConversation.map((msg) => (
                  <div key={msg.id}>
                    <div className="flex items-start gap-2 lg:gap-3">
                      <div className={`w-8 h-8 lg:w-10 lg:h-10 rounded-full bg-gradient-to-br ${msg.color} flex items-center justify-center text-white text-xs lg:text-sm font-bold flex-shrink-0`}>
                        {msg.speakerInitials}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-gray-900 dark:text-gray-100 text-xs lg:text-sm">{msg.speaker}</span>
                          <span className="text-xs text-gray-400 dark:text-gray-500">{msg.timestamp}</span>
                        </div>
                        <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg px-3 lg:px-4 py-2 lg:py-3">
                          <p className="text-xs lg:text-sm text-gray-900 dark:text-gray-100">{msg.message}</p>
                        </div>
                        {msg.reasoning && (
                          <div className="mt-2 bg-purple-50 dark:bg-purple-900/30 border border-purple-200 dark:border-purple-800 rounded-lg px-2 lg:px-3 py-2">
                            <div className="flex items-start gap-2">
                              <Brain className="w-3 h-3 text-purple-600 dark:text-purple-400 mt-0.5 flex-shrink-0" />
                              <p className="text-xs text-purple-900 dark:text-purple-300">{msg.reasoning}</p>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>

            <div className={`border-t border-gray-200 dark:border-gray-700 p-3 lg:p-4 ${currentModeConfig.bgColor.replace('border-', '')}`}>
              <div className="flex items-center justify-center gap-2 text-xs lg:text-sm text-gray-700 dark:text-gray-300">
                <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                <span>Autonomous {currentModeConfig.name.toLowerCase()} in progress...</span>
              </div>
            </div>
          </Card>
        </div>

        {/* Insights Sidebar - Stacked on mobile */}
        <div className="space-y-3 lg:space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Mode Insights</CardTitle>
              <CardDescription>Analysis for {currentModeConfig.name}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {currentInsights.map((insight) => {
                const Icon = insight.icon;
                return (
                  <div key={insight.title} className="pb-4 border-b border-gray-100 last:border-0 last:pb-0">
                    <div className="flex items-start gap-3">
                      <Icon className={`w-5 h-5 ${insight.color} flex-shrink-0 mt-0.5`} />
                      <div>
                        <h4 className="font-medium text-gray-900 text-sm mb-1">{insight.title}</h4>
                        <p className="text-xs text-gray-600">{insight.description}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Conversation Stats</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600 dark:text-gray-400">Total Messages</span>
                <span className="text-lg font-bold text-gray-900 dark:text-gray-100">{currentConversation.length}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600 dark:text-gray-400">Duration</span>
                <span className="text-lg font-bold text-gray-900 dark:text-gray-100">12m</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600 dark:text-gray-400">Naturalness Score</span>
                <span className="text-lg font-bold text-gray-900 dark:text-gray-100">94%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600 dark:text-gray-400">Active Mode</span>
                <Badge className={`${currentModeConfig.bgColor} ${currentModeConfig.color}`}>
                  {currentModeConfig.name}
                </Badge>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Controls</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button variant="outline" className="w-full justify-start">
                <MessageSquare className="w-4 h-4 mr-2" />
                Export Conversation
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Brain className="w-4 h-4 mr-2" />
                View Learning Points
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Zap className="w-4 h-4 mr-2" />
                Adjust Autonomy Level
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}