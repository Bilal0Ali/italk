
  # Wireframe for italk platform

  This is a code bundle for Wireframe for italk platform. The original project is available at https://www.figma.com/design/zlqi8fBRI6LxNpdX6vfNkl/Wireframe-for-italk-platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  